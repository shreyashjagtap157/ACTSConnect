package com.actsconnect.dto;

import lombok.Data;

@Data
public class JobsDto {

	private String title;
	private String description;
	private String company;
	private String location;

}
