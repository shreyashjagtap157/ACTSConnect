package com.actsconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class ActsConnectBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActsConnectBackendApplication.class, args);
	}

}
