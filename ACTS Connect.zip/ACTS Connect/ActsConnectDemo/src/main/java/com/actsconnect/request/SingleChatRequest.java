package com.actsconnect.request;

import lombok.Data;

@Data
public class SingleChatRequest {
	
	private Integer userId;


}
