package com.actsconnect.exception;

public class CommentException extends Exception {
	
	public CommentException() {
		super();
	}
	
	public CommentException(String message) {
		super(message);
	}

}
